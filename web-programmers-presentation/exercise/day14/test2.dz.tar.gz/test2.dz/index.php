<?php

require './autoload.php';

$c= isset($_GET['c']) ? $_GET['c'] : 'main';
$action = isset($_GET['a']) ? $_GET['a'] : 'index';

$cC = "\\IABS\\MVC\\Controller\\" . ucfirst($c);

try {
    $controller = new $cC;
    $controller->$action();     
} catch (\Throwable $ex) {
    echo "Undefined component php v7";
}
   

