<?php
namespace IABS\MVC\Controller;

use IABS\MVC\Model;
use IABS\MVC\View;

class Main {
    public function index() {
        $model = new Model\Main();
        $view = new View\Main();
        
        $view->renderIndex($model->getArticles());
    }
    public function contact() {
        echo "gg";
    }
}
