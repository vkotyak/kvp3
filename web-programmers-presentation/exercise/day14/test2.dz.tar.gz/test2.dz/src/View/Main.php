<?php
namespace IABS\MVC\View;

class Main {
    public function renderIndex($art){
        echo "<ul>";
        foreach ($art as $a) {
            echo "<li>", $a, "</li>";
        }
        echo "</ul>";
    }
}
