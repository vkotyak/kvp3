<?php
namespace IABS\MVC\Model;

class Main {
    public function getArticles() {
        return array(
            "Статья 1",
            "Статья 2",
            "Статья 3"
        );
    }
}
