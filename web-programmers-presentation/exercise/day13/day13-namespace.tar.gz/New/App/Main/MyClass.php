<?php

namespace App\Main;

class MyClass {
    public function hello(){
        echo "App\Main", "<br>\n";
    }
}