<?php

namespace App\Secondary;

class MyClass {
    public function hello(){
        echo "App\Secondary", "<br>\n";
    }
}