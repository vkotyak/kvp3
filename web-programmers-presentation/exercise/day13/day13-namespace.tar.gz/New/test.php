<?php
ini_set('display_errors', 1);
error_reporting(E_ALL);
/*
 * Убедитесь, что без пространств имен нельзя объявить класс с одинаковым именем
class Test {
}
class Test {
}
*/

require_once "App/Main/MyClass.php";
require_once "App/Secondary/MyClass.php";

