<?php
function send_report ($email, $realname, $report) {
    $report_id = md5($email.$realname.$report);
    $filepath = "reports.csv";
    file_put_contents($filepath, $email.','.$realname.','.$report.','.$report_id."\r\n", FILE_APPEND);
}

function get_reports() {
    $file = fopen('reports.csv', 'a+');
    $result = array();
    while (($line = fgetcsv($file)) !== FALSE) {
        $result[] = array(
            'email' => $line[0],
            'realName' => $line[1],
            'content' => $line[2],
            'id' => $line[3],
        );
    }
    fclose($file);
    return $result;
}