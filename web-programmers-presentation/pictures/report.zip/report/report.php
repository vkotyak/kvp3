<?php
require 'functions.php';
if (isset($_POST["userName"]) && isset($_POST['userRealName']) && isset($_POST['report'])) {
    send_report($_POST['userName'], $_POST['userRealName'], $_POST['report']);
    echo "<script>alert('Отчет отправлен!');</script>";
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link rel="stylesheet" href="https://code.getmdl.io/1.3.0/material.teal-pink.min.css">
    <script defer src="https://code.getmdl.io/1.3.0/material.min.js"></script>
    <title>Отправка</title>
</head>
<body>
<!-- Always shows a header, even in smaller screens. -->
<div class="mdl-layout mdl-js-layout mdl-layout--fixed-header">
    <header class="mdl-layout__header">
        <div class="mdl-layout__header-row">
            <!-- Title -->
            <span class="mdl-layout-title">Отправка отчета</span>
            <!-- Add spacer, to align navigation to the right -->
            <div class="mdl-layout-spacer"></div>
            <!-- Navigation. We hide it in small screens. -->
            <nav class="mdl-navigation mdl-layout--large-screen-only">
                <a class="mdl-navigation__link" href="viewreports.php">Просмотр отчетов</a>
            </nav>
        </div>
    </header>
    <main class="mdl-layout__content">
        <div class="page-content">
            <form action="report.php" method="post">
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="email" id="userName" name="userName">
                    <label class="mdl-textfield__label" for="userName">Электронный адрес</label>
                </div>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" id="userRealName" name="userRealName">
                    <label class="mdl-textfield__label" for="userRealName">Ваше имя и фамилия</label>
                </div><br>
                <div class="mdl-textfield mdl-js-textfield">
                    <input class="mdl-textfield__input" type="text" id="userPassword" name="report" required>
                    <label class="mdl-textfield__label" for="userPassword">Текст</label>
                </div>
                <button class="mdl-button mdl-js-button mdl-button--raised mdl-button--colored" type="submit">
                    Отправить
                </button>
            </form>
        </div>
    </main>
</div>
</body>
</html>